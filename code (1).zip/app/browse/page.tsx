"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Heart, ArrowLeft } from "lucide-react"

// Mock pet data
const MOCK_PETS = [
  {
    id: 1,
    name: "Max",
    type: "Dog",
    breed: "Golden Retriever",
    age: 2,
    image: "/golden-retriever-dog.jpg",
    description: "Friendly and energetic golden retriever looking for an active family.",
    location: "San Francisco, CA",
  },
  {
    id: 2,
    name: "Luna",
    type: "Cat",
    breed: "Siamese",
    age: 1,
    image: "/siamese-cat.jpg",
    description: "Playful and affectionate Siamese cat with beautiful blue eyes.",
    location: "Los Angeles, CA",
  },
  {
    id: 3,
    name: "Charlie",
    type: "Dog",
    breed: "Labrador",
    age: 3,
    image: "/labrador-dog.jpg",
    description: "Gentle and loyal Labrador, great with kids and other pets.",
    location: "New York, NY",
  },
  {
    id: 4,
    name: "Whiskers",
    type: "Cat",
    breed: "Maine Coon",
    age: 2,
    image: "/maine-coon-cat.jpg",
    description: "Majestic Maine Coon with a calm and loving temperament.",
    location: "Boston, MA",
  },
  {
    id: 5,
    name: "Buddy",
    type: "Dog",
    breed: "Beagle",
    age: 1,
    image: "/beagle-dog.jpg",
    description: "Curious and playful Beagle puppy full of energy and love.",
    location: "Chicago, IL",
  },
  {
    id: 6,
    name: "Mittens",
    type: "Cat",
    breed: "Tabby",
    age: 4,
    image: "/tabby-cat.jpg",
    description: "Sweet and calm tabby cat, perfect for a quiet home.",
    location: "Seattle, WA",
  },
]

export default function BrowsePage() {
  const [favorites, setFavorites] = useState<number[]>([])
  const [selectedType, setSelectedType] = useState<string>("All")

  const filteredPets = selectedType === "All" ? MOCK_PETS : MOCK_PETS.filter((pet) => pet.type === selectedType)

  const toggleFavorite = (id: number) => {
    setFavorites((prev) => (prev.includes(id) ? prev.filter((fav) => fav !== id) : [...prev, id]))
  }

  return (
    <main className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-gradient-to-r from-primary to-accent text-primary-foreground py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Link href="/" className="inline-flex items-center gap-2 mb-4 hover:opacity-80">
            <ArrowLeft className="w-5 h-5" />
            Back Home
          </Link>
          <h1 className="text-4xl font-bold">Browse Available Pets</h1>
          <p className="text-primary-foreground/90 mt-2">Find your perfect companion</p>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-card border-b border-border sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex gap-2 flex-wrap">
            {["All", "Dog", "Cat"].map((type) => (
              <Button
                key={type}
                variant={selectedType === type ? "default" : "outline"}
                onClick={() => setSelectedType(type)}
                className={selectedType === type ? "bg-primary text-primary-foreground" : ""}
              >
                {type}
              </Button>
            ))}
          </div>
        </div>
      </div>

      {/* Pet Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredPets.map((pet) => (
            <Card key={pet.id} className="overflow-hidden hover:shadow-lg transition-shadow">
              <div className="relative">
                <img src={pet.image || "/placeholder.svg"} alt={pet.name} className="w-full h-64 object-cover" />
                <button
                  onClick={() => toggleFavorite(pet.id)}
                  className="absolute top-3 right-3 bg-white rounded-full p-2 hover:bg-muted transition-colors"
                >
                  <Heart
                    className={`w-6 h-6 ${favorites.includes(pet.id) ? "fill-primary text-primary" : "text-muted-foreground"}`}
                  />
                </button>
              </div>
              <div className="p-4">
                <h3 className="text-xl font-bold text-card-foreground mb-1">{pet.name}</h3>
                <p className="text-sm text-muted-foreground mb-3">
                  {pet.breed} • {pet.age} years old
                </p>
                <p className="text-sm text-muted-foreground mb-4 line-clamp-2">{pet.description}</p>
                <p className="text-xs text-muted-foreground mb-4">📍 {pet.location}</p>
                <Link href={`/pet/${pet.id}`}>
                  <Button className="w-full bg-primary hover:bg-primary/90 text-primary-foreground">
                    View Details
                  </Button>
                </Link>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </main>
  )
}
