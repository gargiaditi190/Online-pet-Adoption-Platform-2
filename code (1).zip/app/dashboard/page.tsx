"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { ArrowLeft, Clock, CheckCircle, XCircle } from "lucide-react"

const MOCK_APPLICATIONS = [
  {
    id: 1,
    petName: "Max",
    petImage: "/golden-retriever-dog.jpg",
    status: "pending",
    appliedDate: "2024-10-15",
    statusText: "Under Review",
  },
  {
    id: 2,
    petName: "Luna",
    petImage: "/siamese-cat.jpg",
    status: "approved",
    appliedDate: "2024-10-10",
    statusText: "Approved",
  },
]

export default function DashboardPage() {
  return (
    <main className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-gradient-to-r from-primary to-accent text-primary-foreground py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Link href="/" className="inline-flex items-center gap-2 mb-4 hover:opacity-80">
            <ArrowLeft className="w-5 h-5" />
            Back Home
          </Link>
          <h1 className="text-4xl font-bold">My Dashboard</h1>
          <p className="text-primary-foreground/90 mt-2">Track your adoption applications</p>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Stats */}
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Total Applications</p>
                <p className="text-3xl font-bold text-card-foreground">{MOCK_APPLICATIONS.length}</p>
              </div>
              <Clock className="w-12 h-12 text-secondary opacity-50" />
            </div>
          </Card>
          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Approved</p>
                <p className="text-3xl font-bold text-card-foreground">
                  {MOCK_APPLICATIONS.filter((a) => a.status === "approved").length}
                </p>
              </div>
              <CheckCircle className="w-12 h-12 text-green-500 opacity-50" />
            </div>
          </Card>
          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Pending</p>
                <p className="text-3xl font-bold text-card-foreground">
                  {MOCK_APPLICATIONS.filter((a) => a.status === "pending").length}
                </p>
              </div>
              <Clock className="w-12 h-12 text-accent opacity-50" />
            </div>
          </Card>
        </div>

        {/* Applications */}
        <div>
          <h2 className="text-2xl font-bold text-foreground mb-6">Your Applications</h2>
          <div className="space-y-4">
            {MOCK_APPLICATIONS.map((app) => (
              <Card key={app.id} className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <img
                      src={app.petImage || "/placeholder.svg"}
                      alt={app.petName}
                      className="w-20 h-20 rounded-lg object-cover"
                    />
                    <div>
                      <h3 className="text-lg font-semibold text-card-foreground">{app.petName}</h3>
                      <p className="text-sm text-muted-foreground">Applied: {app.appliedDate}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div
                      className={`inline-flex items-center gap-2 px-3 py-1 rounded-full ${
                        app.status === "approved"
                          ? "bg-green-100 text-green-700"
                          : app.status === "pending"
                            ? "bg-yellow-100 text-yellow-700"
                            : "bg-red-100 text-red-700"
                      }`}
                    >
                      {app.status === "approved" && <CheckCircle className="w-4 h-4" />}
                      {app.status === "pending" && <Clock className="w-4 h-4" />}
                      {app.status === "rejected" && <XCircle className="w-4 h-4" />}
                      <span className="text-sm font-medium">{app.statusText}</span>
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>

        {/* CTA */}
        <div className="mt-12 text-center">
          <Link href="/browse">
            <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">Browse More Pets</Button>
          </Link>
        </div>
      </div>
    </main>
  )
}
