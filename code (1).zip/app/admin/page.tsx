"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { ArrowLeft, Plus, Edit2, Trash2 } from "lucide-react"

const MOCK_ADMIN_PETS = [
  {
    id: 1,
    name: "Max",
    breed: "Golden Retriever",
    status: "available",
    image: "/golden-retriever-dog.jpg",
  },
  {
    id: 2,
    name: "Luna",
    breed: "Siamese",
    status: "adopted",
    image: "/siamese-cat.jpg",
  },
]

const MOCK_APPLICATIONS = [
  {
    id: 1,
    applicantName: "John Doe",
    petName: "Max",
    status: "pending",
    appliedDate: "2024-10-15",
  },
  {
    id: 2,
    applicantName: "Jane Smith",
    petName: "Luna",
    status: "approved",
    appliedDate: "2024-10-10",
  },
]

export default function AdminPage() {
  const [activeTab, setActiveTab] = useState<"pets" | "applications">("pets")

  return (
    <main className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-gradient-to-r from-primary to-accent text-primary-foreground py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Link href="/" className="inline-flex items-center gap-2 mb-4 hover:opacity-80">
            <ArrowLeft className="w-5 h-5" />
            Back Home
          </Link>
          <h1 className="text-4xl font-bold">Admin Dashboard</h1>
          <p className="text-primary-foreground/90 mt-2">Manage pets and applications</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-card border-b border-border sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex gap-4">
            <button
              onClick={() => setActiveTab("pets")}
              className={`px-4 py-4 font-medium border-b-2 transition-colors ${
                activeTab === "pets"
                  ? "border-primary text-primary"
                  : "border-transparent text-muted-foreground hover:text-foreground"
              }`}
            >
              Manage Pets
            </button>
            <button
              onClick={() => setActiveTab("applications")}
              className={`px-4 py-4 font-medium border-b-2 transition-colors ${
                activeTab === "applications"
                  ? "border-primary text-primary"
                  : "border-transparent text-muted-foreground hover:text-foreground"
              }`}
            >
              Applications
            </button>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {activeTab === "pets" && (
          <div>
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-foreground">Pets</h2>
              <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
                <Plus className="w-5 h-5 mr-2" />
                Add Pet
              </Button>
            </div>

            <div className="space-y-4">
              {MOCK_ADMIN_PETS.map((pet) => (
                <Card key={pet.id} className="p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <img
                        src={pet.image || "/placeholder.svg"}
                        alt={pet.name}
                        className="w-16 h-16 rounded-lg object-cover"
                      />
                      <div>
                        <h3 className="text-lg font-semibold text-card-foreground">{pet.name}</h3>
                        <p className="text-sm text-muted-foreground">{pet.breed}</p>
                        <span
                          className={`inline-block mt-2 px-2 py-1 rounded text-xs font-medium ${
                            pet.status === "available" ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-700"
                          }`}
                        >
                          {pet.status}
                        </span>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm">
                        <Edit2 className="w-4 h-4" />
                      </Button>
                      <Button variant="outline" size="sm">
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        )}

        {activeTab === "applications" && (
          <div>
            <h2 className="text-2xl font-bold text-foreground mb-6">Applications</h2>

            <div className="space-y-4">
              {MOCK_APPLICATIONS.map((app) => (
                <Card key={app.id} className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-lg font-semibold text-card-foreground">{app.applicantName}</h3>
                      <p className="text-sm text-muted-foreground">Applied for: {app.petName}</p>
                      <p className="text-xs text-muted-foreground mt-1">Applied: {app.appliedDate}</p>
                    </div>
                    <div className="flex items-center gap-4">
                      <span
                        className={`px-3 py-1 rounded-full text-sm font-medium ${
                          app.status === "approved"
                            ? "bg-green-100 text-green-700"
                            : app.status === "pending"
                              ? "bg-yellow-100 text-yellow-700"
                              : "bg-red-100 text-red-700"
                        }`}
                      >
                        {app.status}
                      </span>
                      <Button variant="outline" size="sm">
                        Review
                      </Button>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        )}
      </div>
    </main>
  )
}
