"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Heart, ArrowLeft, MapPin, Calendar, Tag } from "lucide-react"

// Mock pet data
const MOCK_PETS: Record<string, any> = {
  "1": {
    id: 1,
    name: "Max",
    type: "Dog",
    breed: "Golden Retriever",
    age: 2,
    image: "/golden-retriever-dog.jpg",
    description: "Friendly and energetic golden retriever looking for an active family.",
    location: "San Francisco, CA",
    gender: "Male",
    weight: "65 lbs",
    vaccinated: true,
    neutered: true,
    fullDescription:
      "Max is a wonderful 2-year-old Golden Retriever with a heart full of love. He is incredibly friendly, loves to play fetch, and enjoys swimming. Max is great with children and other dogs. He would thrive in an active family that can provide him with regular exercise and lots of affection.",
  },
  "2": {
    id: 2,
    name: "Luna",
    type: "Cat",
    breed: "Siamese",
    age: 1,
    image: "/siamese-cat.jpg",
    description: "Playful and affectionate Siamese cat with beautiful blue eyes.",
    location: "Los Angeles, CA",
    gender: "Female",
    weight: "8 lbs",
    vaccinated: true,
    neutered: false,
    fullDescription:
      "Luna is a stunning 1-year-old Siamese cat with striking blue eyes. She is very playful, loves interactive toys, and enjoys being around people. Luna would do best in a home where she can get plenty of attention and playtime.",
  },
}

export default function PetDetailPage({ params }: { params: { id: string } }) {
  const pet = MOCK_PETS[params.id]
  const [isFavorite, setIsFavorite] = useState(false)

  if (!pet) {
    return (
      <main className="min-h-screen bg-background">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 text-center">
          <h1 className="text-2xl font-bold text-foreground mb-4">Pet not found</h1>
          <Link href="/browse">
            <Button>Back to Browse</Button>
          </Link>
        </div>
      </main>
    )
  }

  return (
    <main className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-card border-b border-border">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <Link href="/browse" className="inline-flex items-center gap-2 text-primary hover:text-primary/80 mb-4">
            <ArrowLeft className="w-5 h-5" />
            Back to Browse
          </Link>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid md:grid-cols-3 gap-8">
          {/* Image and Quick Info */}
          <div className="md:col-span-2">
            <div className="relative mb-6">
              <img
                src={pet.image || "/placeholder.svg"}
                alt={pet.name}
                className="w-full rounded-lg object-cover h-96"
              />
              <button
                onClick={() => setIsFavorite(!isFavorite)}
                className="absolute top-4 right-4 bg-white rounded-full p-3 hover:bg-muted transition-colors shadow-lg"
              >
                <Heart className={`w-6 h-6 ${isFavorite ? "fill-primary text-primary" : "text-muted-foreground"}`} />
              </button>
            </div>

            {/* Details */}
            <Card className="p-6 mb-6">
              <h1 className="text-4xl font-bold text-card-foreground mb-4">{pet.name}</h1>
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Tag className="w-5 h-5" />
                  <span>{pet.breed}</span>
                </div>
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Calendar className="w-5 h-5" />
                  <span>{pet.age} years old</span>
                </div>
                <div className="flex items-center gap-2 text-muted-foreground">
                  <MapPin className="w-5 h-5" />
                  <span>{pet.location}</span>
                </div>
                <div className="text-muted-foreground">
                  <span>
                    {pet.gender} • {pet.weight}
                  </span>
                </div>
              </div>

              <div className="border-t border-border pt-4">
                <h3 className="font-semibold text-card-foreground mb-3">Health Status</h3>
                <div className="flex gap-4">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-green-500"></div>
                    <span className="text-sm text-muted-foreground">Vaccinated</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className={`w-3 h-3 rounded-full ${pet.neutered ? "bg-green-500" : "bg-yellow-500"}`}></div>
                    <span className="text-sm text-muted-foreground">{pet.neutered ? "Neutered" : "Not neutered"}</span>
                  </div>
                </div>
              </div>
            </Card>

            {/* Full Description */}
            <Card className="p-6">
              <h2 className="text-2xl font-bold text-card-foreground mb-4">About {pet.name}</h2>
              <p className="text-muted-foreground leading-relaxed">{pet.fullDescription}</p>
            </Card>
          </div>

          {/* Sidebar - Application */}
          <div>
            <Card className="p-6 sticky top-4">
              <h3 className="text-xl font-bold text-card-foreground mb-4">Ready to Adopt?</h3>
              <p className="text-sm text-muted-foreground mb-6">
                Start the adoption process for {pet.name}. Our team will review your application and get back to you
                within 48 hours.
              </p>
              <Link href={`/apply/${pet.id}`}>
                <Button className="w-full bg-primary hover:bg-primary/90 text-primary-foreground mb-3">
                  Apply for Adoption
                </Button>
              </Link>
              <Button variant="outline" className="w-full bg-transparent">
                Contact Shelter
              </Button>

              <div className="mt-6 pt-6 border-t border-border">
                <h4 className="font-semibold text-card-foreground mb-3">Adoption Requirements</h4>
                <ul className="text-sm text-muted-foreground space-y-2">
                  <li>✓ Must be 18+ years old</li>
                  <li>✓ Valid ID required</li>
                  <li>✓ Home visit may be required</li>
                  <li>✓ Adoption fee applies</li>
                </ul>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </main>
  )
}
