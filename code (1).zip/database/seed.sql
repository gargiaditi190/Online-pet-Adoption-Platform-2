-- Seed data for Pet Adoption Platform

USE pet_adoption;

-- Insert sample users
INSERT INTO users (email, password, full_name, phone, role) VALUES
('admin@petadopt.com', 'admin123', 'Admin User', '555-0001', 'admin'),
('john.doe@email.com', 'password123', 'John Doe', '555-0002', 'user'),
('jane.smith@email.com', 'password123', 'Jane Smith', '555-0003', 'user');

-- Insert sample pets
INSERT INTO pets (name, type, breed, age, gender, size, description, image_url, status, vaccinated, spayed_neutered, location) VALUES
('Max', 'Dog', 'Golden Retriever', 3, 'Male', 'Large', 
 'Max is a friendly and energetic Golden Retriever who loves to play fetch and go on long walks. He is great with children and other dogs.', 
 '/images/golden-retriever.jpg', 'Available', TRUE, TRUE, 'New York, NY'),

('Luna', 'Cat', 'Siamese', 2, 'Female', 'Medium', 
 'Luna is a beautiful Siamese cat with striking blue eyes. She is independent but affectionate and loves to curl up on your lap.', 
 '/images/siamese-cat.jpg', 'Available', TRUE, TRUE, 'Los Angeles, CA'),

('Buddy', 'Dog', 'Labrador Retriever', 5, 'Male', 'Large', 
 'Buddy is a calm and gentle Labrador who is perfect for families. He is well-trained and loves water.', 
 '/images/labrador.jpg', 'Available', TRUE, TRUE, 'Chicago, IL'),

('Bella', 'Cat', 'Persian', 1, 'Female', 'Small', 
 'Bella is a young Persian cat with a luxurious coat. She is playful and curious, always exploring her surroundings.', 
 '/images/persian-cat.jpg', 'Available', TRUE, FALSE, 'Houston, TX'),

('Charlie', 'Dog', 'Beagle', 4, 'Male', 'Medium', 
 'Charlie is an adventurous Beagle with a great sense of smell. He loves outdoor activities and is very friendly.', 
 '/images/beagle.jpg', 'Available', TRUE, TRUE, 'Phoenix, AZ'),

('Milo', 'Cat', 'Maine Coon', 3, 'Male', 'Large', 
 'Milo is a majestic Maine Coon with a fluffy coat. He is gentle, social, and gets along well with other pets.', 
 '/images/maine-coon.jpg', 'Available', TRUE, TRUE, 'Philadelphia, PA');

-- Insert sample applications
INSERT INTO applications (user_id, pet_id, full_name, email, phone, address, city, state, zip_code, 
                         occupation, housing_type, has_yard, has_pets, experience, reason, status) VALUES
(2, 1, 'John Doe', 'john.doe@email.com', '555-0002', '123 Main St', 'New York', 'NY', '10001',
 'Software Engineer', 'House', TRUE, FALSE, 'I grew up with dogs and have experience caring for them.', 
 'I would love to give Max a loving home and plenty of exercise.', 'Pending'),

(3, 2, 'Jane Smith', 'jane.smith@email.com', '555-0003', '456 Oak Ave', 'Los Angeles', 'CA', '90001',
 'Teacher', 'Apartment', FALSE, TRUE, 'I have had cats all my life and understand their needs.', 
 'Luna would be a perfect companion for me and my current cat.', 'Approved');
