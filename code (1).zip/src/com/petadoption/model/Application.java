package com.petadoption.model;

import java.sql.Timestamp;

/**
 * Application Model Class
 * Represents an adoption application
 */
public class Application {
    private int id;
    private int userId;
    private int petId;
    private String fullName;
    private String email;
    private String phone;
    private String address;
    private String city;
    private String state;
    private String zipCode;
    private String occupation;
    private String housingType; // House, Apartment, Condo
    private boolean hasYard;
    private boolean hasPets;
    private String currentPets;
    private String experience;
    private String reason;
    private String status; // Pending, Approved, Rejected
    private Timestamp createdAt;
    private Timestamp updatedAt;
    
    // Constructors
    public Application() {}
    
    // Getters and Setters
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public int getUserId() {
        return userId;
    }
    
    public void setUserId(int userId) {
        this.userId = userId;
    }
    
    public int getPetId() {
        return petId;
    }
    
    public void setPetId(int petId) {
        this.petId = petId;
    }
    
    public String getFullName() {
        return fullName;
    }
    
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }
    
    public String getEmail() {
        return email;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    
    public String getPhone() {
        return phone;
    }
    
    public void setPhone(String phone) {
        this.phone = phone;
    }
    
    public String getAddress() {
        return address;
    }
    
    public void setAddress(String address) {
        this.address = address;
    }
    
    public String getCity() {
        return city;
    }
    
    public void setCity(String city) {
        this.city = city;
    }
    
    public String getState() {
        return state;
    }
    
    public void setState(String state) {
        this.state = state;
    }
    
    public String getZipCode() {
        return zipCode;
    }
    
    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }
    
    public String getOccupation() {
        return occupation;
    }
    
    public void setOccupation(String occupation) {
        this.occupation = occupation;
    }
    
    public String getHousingType() {
        return housingType;
    }
    
    public void setHousingType(String housingType) {
        this.housingType = housingType;
    }
    
    public boolean isHasYard() {
        return hasYard;
    }
    
    public void setHasYard(boolean hasYard) {
        this.hasYard = hasYard;
    }
    
    public boolean isHasPets() {
        return hasPets;
    }
    
    public void setHasPets(boolean hasPets) {
        this.hasPets = hasPets;
    }
    
    public String getCurrentPets() {
        return currentPets;
    }
    
    public void setCurrentPets(String currentPets) {
        this.currentPets = currentPets;
    }
    
    public String getExperience() {
        return experience;
    }
    
    public void setExperience(String experience) {
        this.experience = experience;
    }
    
    public String getReason() {
        return reason;
    }
    
    public void setReason(String reason) {
        this.reason = reason;
    }
    
    public String getStatus() {
        return status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    public Timestamp getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }
    
    public Timestamp getUpdatedAt() {
        return updatedAt;
    }
    
    public void setUpdatedAt(Timestamp updatedAt) {
        this.updatedAt = updatedAt;
    }
}
