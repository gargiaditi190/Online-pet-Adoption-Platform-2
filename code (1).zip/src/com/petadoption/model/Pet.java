package com.petadoption.model;

import java.sql.Timestamp;

/**
 * Pet Model Class
 * Represents a pet in the adoption system
 */
public class Pet {
    private int id;
    private String name;
    private String type; // Dog, Cat, etc.
    private String breed;
    private int age;
    private String gender;
    private String size; // Small, Medium, Large
    private String description;
    private String imageUrl;
    private String status; // Available, Pending, Adopted
    private boolean vaccinated;
    private boolean spayedNeutered;
    private String location;
    private Timestamp createdAt;
    private Timestamp updatedAt;
    
    // Constructors
    public Pet() {}
    
    public Pet(String name, String type, String breed, int age, String gender, 
               String size, String description, String imageUrl, String location) {
        this.name = name;
        this.type = type;
        this.breed = breed;
        this.age = age;
        this.gender = gender;
        this.size = size;
        this.description = description;
        this.imageUrl = imageUrl;
        this.location = location;
        this.status = "Available";
    }
    
    // Getters and Setters
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getType() {
        return type;
    }
    
    public void setType(String type) {
        this.type = type;
    }
    
    public String getBreed() {
        return breed;
    }
    
    public void setBreed(String breed) {
        this.breed = breed;
    }
    
    public int getAge() {
        return age;
    }
    
    public void setAge(int age) {
        this.age = age;
    }
    
    public String getGender() {
        return gender;
    }
    
    public void setGender(String gender) {
        this.gender = gender;
    }
    
    public String getSize() {
        return size;
    }
    
    public void setSize(String size) {
        this.size = size;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public String getImageUrl() {
        return imageUrl;
    }
    
    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }
    
    public String getStatus() {
        return status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    public boolean isVaccinated() {
        return vaccinated;
    }
    
    public void setVaccinated(boolean vaccinated) {
        this.vaccinated = vaccinated;
    }
    
    public boolean isSpayedNeutered() {
        return spayedNeutered;
    }
    
    public void setSpayedNeutered(boolean spayedNeutered) {
        this.spayedNeutered = spayedNeutered;
    }
    
    public String getLocation() {
        return location;
    }
    
    public void setLocation(String location) {
        this.location = location;
    }
    
    public Timestamp getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }
    
    public Timestamp getUpdatedAt() {
        return updatedAt;
    }
    
    public void setUpdatedAt(Timestamp updatedAt) {
        this.updatedAt = updatedAt;
    }
}
