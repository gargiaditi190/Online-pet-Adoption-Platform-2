package com.petadoption.dao;

import com.petadoption.model.Pet;
import com.petadoption.util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Pet Data Access Object
 * Handles all database operations for Pet entities
 */
public class PetDAO {
    
    /**
     * Get all pets from database
     */
    public List<Pet> getAllPets() throws SQLException {
        List<Pet> pets = new ArrayList<>();
        String sql = "SELECT * FROM pets ORDER BY created_at DESC";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            while (rs.next()) {
                pets.add(extractPetFromResultSet(rs));
            }
        }
        
        return pets;
    }
    
    /**
     * Get pets by type (Dog, Cat, etc.)
     */
    public List<Pet> getPetsByType(String type) throws SQLException {
        List<Pet> pets = new ArrayList<>();
        String sql = "SELECT * FROM pets WHERE type = ? AND status = 'Available' ORDER BY created_at DESC";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, type);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    pets.add(extractPetFromResultSet(rs));
                }
            }
        }
        
        return pets;
    }
    
    /**
     * Get pet by ID
     */
    public Pet getPetById(int id) throws SQLException {
        String sql = "SELECT * FROM pets WHERE id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return extractPetFromResultSet(rs);
                }
            }
        }
        
        return null;
    }
    
    /**
     * Insert new pet
     */
    public boolean insertPet(Pet pet) throws SQLException {
        String sql = "INSERT INTO pets (name, type, breed, age, gender, size, description, " +
                    "image_url, status, vaccinated, spayed_neutered, location) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, pet.getName());
            stmt.setString(2, pet.getType());
            stmt.setString(3, pet.getBreed());
            stmt.setInt(4, pet.getAge());
            stmt.setString(5, pet.getGender());
            stmt.setString(6, pet.getSize());
            stmt.setString(7, pet.getDescription());
            stmt.setString(8, pet.getImageUrl());
            stmt.setString(9, pet.getStatus());
            stmt.setBoolean(10, pet.isVaccinated());
            stmt.setBoolean(11, pet.isSpayedNeutered());
            stmt.setString(12, pet.getLocation());
            
            return stmt.executeUpdate() > 0;
        }
    }
    
    /**
     * Update pet information
     */
    public boolean updatePet(Pet pet) throws SQLException {
        String sql = "UPDATE pets SET name = ?, type = ?, breed = ?, age = ?, gender = ?, " +
                    "size = ?, description = ?, image_url = ?, status = ?, vaccinated = ?, " +
                    "spayed_neutered = ?, location = ?, updated_at = CURRENT_TIMESTAMP " +
                    "WHERE id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, pet.getName());
            stmt.setString(2, pet.getType());
            stmt.setString(3, pet.getBreed());
            stmt.setInt(4, pet.getAge());
            stmt.setString(5, pet.getGender());
            stmt.setString(6, pet.getSize());
            stmt.setString(7, pet.getDescription());
            stmt.setString(8, pet.getImageUrl());
            stmt.setString(9, pet.getStatus());
            stmt.setBoolean(10, pet.isVaccinated());
            stmt.setBoolean(11, pet.isSpayedNeutered());
            stmt.setString(12, pet.getLocation());
            stmt.setInt(13, pet.getId());
            
            return stmt.executeUpdate() > 0;
        }
    }
    
    /**
     * Delete pet by ID
     */
    public boolean deletePet(int id) throws SQLException {
        String sql = "DELETE FROM pets WHERE id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        }
    }
    
    /**
     * Get count of pets by status
     */
    public int getPetCountByStatus(String status) throws SQLException {
        String sql = "SELECT COUNT(*) FROM pets WHERE status = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, status);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        }
        
        return 0;
    }
    
    /**
     * Extract Pet object from ResultSet
     */
    private Pet extractPetFromResultSet(ResultSet rs) throws SQLException {
        Pet pet = new Pet();
        pet.setId(rs.getInt("id"));
        pet.setName(rs.getString("name"));
        pet.setType(rs.getString("type"));
        pet.setBreed(rs.getString("breed"));
        pet.setAge(rs.getInt("age"));
        pet.setGender(rs.getString("gender"));
        pet.setSize(rs.getString("size"));
        pet.setDescription(rs.getString("description"));
        pet.setImageUrl(rs.getString("image_url"));
        pet.setStatus(rs.getString("status"));
        pet.setVaccinated(rs.getBoolean("vaccinated"));
        pet.setSpayedNeutered(rs.getBoolean("spayed_neutered"));
        pet.setLocation(rs.getString("location"));
        pet.setCreatedAt(rs.getTimestamp("created_at"));
        pet.setUpdatedAt(rs.getTimestamp("updated_at"));
        return pet;
    }
}
