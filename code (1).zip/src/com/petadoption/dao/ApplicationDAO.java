package com.petadoption.dao;

import com.petadoption.model.Application;
import com.petadoption.util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Application Data Access Object
 * Handles all database operations for Application entities
 */
public class ApplicationDAO {
    
    /**
     * Get all applications
     */
    public List<Application> getAllApplications() throws SQLException {
        List<Application> applications = new ArrayList<>();
        String sql = "SELECT * FROM applications ORDER BY created_at DESC";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            while (rs.next()) {
                applications.add(extractApplicationFromResultSet(rs));
            }
        }
        
        return applications;
    }
    
    /**
     * Get applications by user ID
     */
    public List<Application> getApplicationsByUserId(int userId) throws SQLException {
        List<Application> applications = new ArrayList<>();
        String sql = "SELECT * FROM applications WHERE user_id = ? ORDER BY created_at DESC";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, userId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    applications.add(extractApplicationFromResultSet(rs));
                }
            }
        }
        
        return applications;
    }
    
    /**
     * Get application by ID
     */
    public Application getApplicationById(int id) throws SQLException {
        String sql = "SELECT * FROM applications WHERE id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return extractApplicationFromResultSet(rs);
                }
            }
        }
        
        return null;
    }
    
    /**
     * Insert new application
     */
    public boolean insertApplication(Application app) throws SQLException {
        String sql = "INSERT INTO applications (user_id, pet_id, full_name, email, phone, address, " +
                    "city, state, zip_code, occupation, housing_type, has_yard, has_pets, " +
                    "current_pets, experience, reason, status) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, app.getUserId());
            stmt.setInt(2, app.getPetId());
            stmt.setString(3, app.getFullName());
            stmt.setString(4, app.getEmail());
            stmt.setString(5, app.getPhone());
            stmt.setString(6, app.getAddress());
            stmt.setString(7, app.getCity());
            stmt.setString(8, app.getState());
            stmt.setString(9, app.getZipCode());
            stmt.setString(10, app.getOccupation());
            stmt.setString(11, app.getHousingType());
            stmt.setBoolean(12, app.isHasYard());
            stmt.setBoolean(13, app.isHasPets());
            stmt.setString(14, app.getCurrentPets());
            stmt.setString(15, app.getExperience());
            stmt.setString(16, app.getReason());
            stmt.setString(17, "Pending");
            
            return stmt.executeUpdate() > 0;
        }
    }
    
    /**
     * Update application status
     */
    public boolean updateApplicationStatus(int id, String status) throws SQLException {
        String sql = "UPDATE applications SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, status);
            stmt.setInt(2, id);
            
            return stmt.executeUpdate() > 0;
        }
    }
    
    /**
     * Get application count by status
     */
    public int getApplicationCountByStatus(String status) throws SQLException {
        String sql = "SELECT COUNT(*) FROM applications WHERE status = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, status);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        }
        
        return 0;
    }
    
    /**
     * Extract Application object from ResultSet
     */
    private Application extractApplicationFromResultSet(ResultSet rs) throws SQLException {
        Application app = new Application();
        app.setId(rs.getInt("id"));
        app.setUserId(rs.getInt("user_id"));
        app.setPetId(rs.getInt("pet_id"));
        app.setFullName(rs.getString("full_name"));
        app.setEmail(rs.getString("email"));
        app.setPhone(rs.getString("phone"));
        app.setAddress(rs.getString("address"));
        app.setCity(rs.getString("city"));
        app.setState(rs.getString("state"));
        app.setZipCode(rs.getString("zip_code"));
        app.setOccupation(rs.getString("occupation"));
        app.setHousingType(rs.getString("housing_type"));
        app.setHasYard(rs.getBoolean("has_yard"));
        app.setHasPets(rs.getBoolean("has_pets"));
        app.setCurrentPets(rs.getString("current_pets"));
        app.setExperience(rs.getString("experience"));
        app.setReason(rs.getString("reason"));
        app.setStatus(rs.getString("status"));
        app.setCreatedAt(rs.getTimestamp("created_at"));
        app.setUpdatedAt(rs.getTimestamp("updated_at"));
        return app;
    }
}
