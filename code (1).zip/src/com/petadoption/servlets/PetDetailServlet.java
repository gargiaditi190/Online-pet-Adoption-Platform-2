package com.petadoption.servlets;

import com.petadoption.dao.PetDAO;
import com.petadoption.model.Pet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

/**
 * Pet Detail Servlet
 * Displays detailed information about a specific pet
 */
public class PetDetailServlet extends HttpServlet {
    private PetDAO petDAO;
    
    @Override
    public void init() throws ServletException {
        petDAO = new PetDAO();
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String petIdParam = request.getParameter("id");
        
        if (petIdParam == null || petIdParam.isEmpty()) {
            response.sendRedirect(request.getContextPath() + "/browse");
            return;
        }
        
        try {
            int petId = Integer.parseInt(petIdParam);
            Pet pet = petDAO.getPetById(petId);
            
            if (pet == null) {
                response.sendRedirect(request.getContextPath() + "/browse");
                return;
            }
            
            // Set attributes for JSP
            request.setAttribute("pet", pet);
            
            // Forward to pet-detail.jsp
            request.getRequestDispatcher("/WEB-INF/views/pet-detail.jsp").forward(request, response);
            
        } catch (NumberFormatException e) {
            response.sendRedirect(request.getContextPath() + "/browse");
        } catch (SQLException e) {
            throw new ServletException("Database error: " + e.getMessage(), e);
        }
    }
}
