package com.petadoption.servlets;

import com.petadoption.dao.ApplicationDAO;
import com.petadoption.dao.PetDAO;
import com.petadoption.model.Application;
import com.petadoption.model.Pet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;

/**
 * Adoption Application Servlet
 * Handles adoption application submission
 */
public class AdoptionApplicationServlet extends HttpServlet {
    private ApplicationDAO applicationDAO;
    private PetDAO petDAO;
    
    @Override
    public void init() throws ServletException {
        applicationDAO = new ApplicationDAO();
        petDAO = new PetDAO();
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String petIdParam = request.getParameter("petId");
        
        if (petIdParam == null || petIdParam.isEmpty()) {
            response.sendRedirect(request.getContextPath() + "/browse");
            return;
        }
        
        try {
            int petId = Integer.parseInt(petIdParam);
            Pet pet = petDAO.getPetById(petId);
            
            if (pet == null) {
                response.sendRedirect(request.getContextPath() + "/browse");
                return;
            }
            
            // Set attributes for JSP
            request.setAttribute("pet", pet);
            
            // Forward to application.jsp
            request.getRequestDispatcher("/WEB-INF/views/application.jsp").forward(request, response);
            
        } catch (NumberFormatException e) {
            response.sendRedirect(request.getContextPath() + "/browse");
        } catch (SQLException e) {
            throw new ServletException("Database error: " + e.getMessage(), e);
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("userId") == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        int userId = (Integer) session.getAttribute("userId");
        
        try {
            // Create application object
            Application app = new Application();
            app.setUserId(userId);
            app.setPetId(Integer.parseInt(request.getParameter("petId")));
            app.setFullName(request.getParameter("fullName"));
            app.setEmail(request.getParameter("email"));
            app.setPhone(request.getParameter("phone"));
            app.setAddress(request.getParameter("address"));
            app.setCity(request.getParameter("city"));
            app.setState(request.getParameter("state"));
            app.setZipCode(request.getParameter("zipCode"));
            app.setOccupation(request.getParameter("occupation"));
            app.setHousingType(request.getParameter("housingType"));
            app.setHasYard("on".equals(request.getParameter("hasYard")));
            app.setHasPets("on".equals(request.getParameter("hasPets")));
            app.setCurrentPets(request.getParameter("currentPets"));
            app.setExperience(request.getParameter("experience"));
            app.setReason(request.getParameter("reason"));
            
            // Insert application
            boolean success = applicationDAO.insertApplication(app);
            
            if (success) {
                response.sendRedirect(request.getContextPath() + "/dashboard?submitted=true");
            } else {
                request.setAttribute("error", "Application submission failed");
                doGet(request, response);
            }
            
        } catch (SQLException e) {
            throw new ServletException("Database error: " + e.getMessage(), e);
        }
    }
}
