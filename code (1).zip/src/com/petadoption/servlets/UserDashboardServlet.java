package com.petadoption.servlets;

import com.petadoption.dao.ApplicationDAO;
import com.petadoption.model.Application;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

/**
 * User Dashboard Servlet
 * Displays user's adoption applications
 */
public class UserDashboardServlet extends HttpServlet {
    private ApplicationDAO applicationDAO;
    
    @Override
    public void init() throws ServletException {
        applicationDAO = new ApplicationDAO();
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("userId") == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        int userId = (Integer) session.getAttribute("userId");
        
        try {
            // Get user's applications
            List<Application> applications = applicationDAO.getApplicationsByUserId(userId);
            
            // Set attributes for JSP
            request.setAttribute("applications", applications);
            
            // Forward to dashboard.jsp
            request.getRequestDispatcher("/WEB-INF/views/dashboard.jsp").forward(request, response);
            
        } catch (SQLException e) {
            throw new ServletException("Database error: " + e.getMessage(), e);
        }
    }
}
