package com.petadoption.servlets;

import com.petadoption.dao.PetDAO;
import com.petadoption.model.Pet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

/**
 * Home Servlet
 * Displays the home page with featured pets
 */
public class HomeServlet extends HttpServlet {
    private PetDAO petDAO;
    
    @Override
    public void init() throws ServletException {
        petDAO = new PetDAO();
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        try {
            // Get all available pets
            List<Pet> pets = petDAO.getAllPets();
            
            // Get statistics
            int availablePets = petDAO.getPetCountByStatus("Available");
            
            // Set attributes for JSP
            request.setAttribute("pets", pets);
            request.setAttribute("availablePets", availablePets);
            
            // Forward to home.jsp
            request.getRequestDispatcher("/WEB-INF/views/home.jsp").forward(request, response);
            
        } catch (SQLException e) {
            throw new ServletException("Database error: " + e.getMessage(), e);
        }
    }
}
