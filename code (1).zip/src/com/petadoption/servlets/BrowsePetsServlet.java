package com.petadoption.servlets;

import com.petadoption.dao.PetDAO;
import com.petadoption.model.Pet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

/**
 * Browse Pets Servlet
 * Displays list of pets with filtering options
 */
public class BrowsePetsServlet extends HttpServlet {
    private PetDAO petDAO;
    
    @Override
    public void init() throws ServletException {
        petDAO = new PetDAO();
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String type = request.getParameter("type");
        
        try {
            List<Pet> pets;
            
            if (type != null && !type.isEmpty()) {
                // Filter by type
                pets = petDAO.getPetsByType(type);
            } else {
                // Get all pets
                pets = petDAO.getAllPets();
            }
            
            // Set attributes for JSP
            request.setAttribute("pets", pets);
            request.setAttribute("selectedType", type);
            
            // Forward to browse.jsp
            request.getRequestDispatcher("/WEB-INF/views/browse.jsp").forward(request, response);
            
        } catch (SQLException e) {
            throw new ServletException("Database error: " + e.getMessage(), e);
        }
    }
}
