package com.petadoption.servlets;

import com.petadoption.dao.ApplicationDAO;
import com.petadoption.dao.PetDAO;
import com.petadoption.model.Application;
import com.petadoption.model.Pet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

/**
 * Admin Dashboard Servlet
 * Manages pets and adoption applications
 */
public class AdminDashboardServlet extends HttpServlet {
    private PetDAO petDAO;
    private ApplicationDAO applicationDAO;
    
    @Override
    public void init() throws ServletException {
        petDAO = new PetDAO();
        applicationDAO = new ApplicationDAO();
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || !"admin".equals(session.getAttribute("userRole"))) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        try {
            // Get all pets and applications
            List<Pet> pets = petDAO.getAllPets();
            List<Application> applications = applicationDAO.getAllApplications();
            
            // Get statistics
            int totalPets = pets.size();
            int availablePets = petDAO.getPetCountByStatus("Available");
            int pendingApplications = applicationDAO.getApplicationCountByStatus("Pending");
            
            // Set attributes for JSP
            request.setAttribute("pets", pets);
            request.setAttribute("applications", applications);
            request.setAttribute("totalPets", totalPets);
            request.setAttribute("availablePets", availablePets);
            request.setAttribute("pendingApplications", pendingApplications);
            
            // Forward to admin.jsp
            request.getRequestDispatcher("/WEB-INF/views/admin.jsp").forward(request, response);
            
        } catch (SQLException e) {
            throw new ServletException("Database error: " + e.getMessage(), e);
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String action = request.getParameter("action");
        
        try {
            if ("approveApplication".equals(action)) {
                int appId = Integer.parseInt(request.getParameter("applicationId"));
                applicationDAO.updateApplicationStatus(appId, "Approved");
            } else if ("rejectApplication".equals(action)) {
                int appId = Integer.parseInt(request.getParameter("applicationId"));
                applicationDAO.updateApplicationStatus(appId, "Rejected");
            }
            
            response.sendRedirect(request.getContextPath() + "/admin");
            
        } catch (SQLException e) {
            throw new ServletException("Database error: " + e.getMessage(), e);
        }
    }
}
